# Umesh Sutar — 3D Developer Portfolio

Premium React + TypeScript portfolio built from the supplied resume and professional photo.

## Run locally

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## Source of truth

All personal, experience, project, skill, and education content is derived from the supplied `Umesh_Sutar_Dotnet_Resume.pdf`. The supplied portrait is used as `public/profile.png` and the original resume as `public/Umesh_Sutar_Dotnet_Resume.pdf`.

No LinkedIn/GitHub profile URL is fabricated because the resume does not provide profile URLs.
