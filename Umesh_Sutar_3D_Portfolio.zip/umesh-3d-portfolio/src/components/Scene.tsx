import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Points, PointMaterial } from '@react-three/drei';
import { useRef } from 'react';
import * as THREE from 'three';

function Orb({ position, scale }: { position: [number, number, number]; scale: number }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (!ref.current) return;
    ref.current.rotation.x = state.clock.elapsedTime * 0.08;
    ref.current.rotation.y = state.clock.elapsedTime * 0.12;
  });
  return <Float speed={1.2} rotationIntensity={0.25} floatIntensity={0.5}>
    <mesh ref={ref} position={position} scale={scale}><icosahedronGeometry args={[1, 1]} /><meshStandardMaterial color="#91a7ff" wireframe transparent opacity={0.24} /></mesh>
  </Float>;
}

function ParticleField() {
  const count = 850;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count * 3; i++) positions[i] = (Math.random() - 0.5) * 14;
  return <Points positions={positions} stride={3} frustumCulled>
    <PointMaterial transparent color="#b8c7ff" size={0.018} sizeAttenuation depthWrite={false} opacity={0.48} />
  </Points>;
}

export default function Scene() {
  return <div className="scene" aria-hidden="true">
    <Canvas camera={{ position: [0, 0, 8], fov: 48 }} dpr={[1, 1.6]} gl={{ antialias: true, alpha: true }}>
      <ambientLight intensity={0.45} />
      <pointLight position={[3, 2, 5]} intensity={8} color="#b9c8ff" distance={12} />
      <pointLight position={[-4, -2, 2]} intensity={4} color="#8a7dff" distance={10} />
      <ParticleField />
      <Orb position={[-4.2, 1.9, -1]} scale={1.2} />
      <Orb position={[4.2, -1.6, -0.8]} scale={0.9} />
      <Orb position={[2.8, 2.6, -2]} scale={0.55} />
    </Canvas>
  </div>;
}
