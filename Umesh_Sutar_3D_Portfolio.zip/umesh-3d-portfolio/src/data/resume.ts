export const resume = {
  name: 'Sutar Umesh Gokul',
  title: '.NET Developer',
  location: 'Ahmedabad, Gujarat, India',
  phone: '8698569031',
  email: 'sutarumesh.info@gmail.com',
  summary: 'Software Developer (.NET Core) with 1.2 years of professional experience and 6 months of internship experience in developing web applications and RESTful Web APIs using C#, ASP.NET Core, .NET Core, Entity Framework Core, LINQ, and SQL Server. Experienced in CRUD operations, business logic, JWT Authentication, Role-Based Authorization, API integration, and exception handling. Hands-on experience with Azure Blob Storage, Swagger, Git, and GitHub, with strong understanding of OOP, MVC, Dependency Injection, and SDLC.',
  skills: {
    'Programming Languages': ['C#', 'SQL'],
    '.NET Technologies': ['.NET Core', 'ASP.NET Core', 'ASP.NET Core Web API', 'ADO.NET'],
    'Web Technologies': ['HTML5', 'CSS3', 'JavaScript', 'jQuery', 'AJAX', 'Bootstrap'],
    Database: ['Microsoft SQL Server', 'SQL Queries', 'Stored Procedures', 'Joins', 'Views'],
    'ORM & Data Access': ['Entity Framework Core', 'LINQ'],
    'Authentication & Security': ['JWT Authentication', 'Role-Based Authorization'],
    'Cloud & APIs': ['Azure Blob Storage', 'Google Maps API', 'RESTful Web APIs', 'JSON'],
    'Tools & Version Control': ['Visual Studio', 'SQL Server Management Studio', 'Swagger', 'Git', 'GitHub'],
    'Development Concepts': ['OOP', 'MVC Architecture', 'Dependency Injection', 'CRUD Operations', 'Exception Handling', 'Input Validation', 'SDLC']
  },
  experience: [
    {
      company: 'HADUX SOFT', role: '.NET Core Developer', dates: '07/2025 – Present', location: 'Pune, Maharashtra',
      bullets: [
        'Designed and developed RESTful Web APIs based on business requirements and implemented business logic using C#, Entity Framework Core, LINQ, and ADO.NET.',
        'Applied Object-Oriented Programming (OOP) concepts to develop clean, reusable, and maintainable application components.',
        'Worked with SQL Server for database queries, data management, stored procedures, and backend integration.',
        'Implemented CRUD operations, data validation, exception handling, and API integration across application modules.',
        'Integrated backend APIs with application components and ensured reliable data flow between application layers.',
        'Identified, debugged, and resolved application issues to improve application stability, performance, and functionality.',
        'Participated in application testing, debugging, maintenance, and feature enhancement activities.',
        'Used Swagger for API documentation and testing of RESTful endpoints.',
        'Followed coding standards, clean coding practices, and software development best practices throughout the development lifecycle.'
      ]
    },
    {
      company: 'HADUX SOFT', role: '.NET Developer Intern', dates: '12/2024 – 06/2025', location: 'Pune, Maharashtra',
      bullets: [
        'Assisted in developing and maintaining .NET-based web applications under the guidance of senior developers.',
        'Worked with C#, .NET Core, and ASP.NET Core for application development and feature implementation.',
        'Used Entity Framework Core and LINQ for database interaction and data retrieval.',
        'Assisted in debugging and resolving application issues to improve application functionality.',
        'Developed and tested RESTful API endpoints and database operations.',
        'Worked with SQL Server for CRUD operations, queries, and data handling.',
        'Gained practical experience in the Software Development Life Cycle (SDLC), coding standards, and software development best practices.',
        'Participated in testing, debugging, and application maintenance activities.'
      ]
    }
  ],
  projects: [
    {
      name: 'Land Layout & Plot Management System',
      technologies: ['C#','ASP.NET Core','ASP.NET Core Web API','Entity Framework Core','SQL Server','JWT','Azure Blob Storage','Google Maps API','Git','GitHub','Swagger'],
      bullets: [
        'Developed and maintained client-based web applications using C#, ASP.NET Core, ASP.NET Core Web API, Entity Framework Core, and SQL Server.',
        'Developed 15+ RESTful APIs for plot and user management using ASP.NET Core Web API and EF Core.',
        'Implemented JWT Authentication and Role-Based Authorization for secure application access.',
        'Integrated Azure Blob Storage to store and manage land layout documents in PDF and image formats.',
        'Designed database entities and relationships and implemented CRUD operations using Entity Framework Core and SQL Server.',
        'Implemented user-specific access control to manage access to individual land layouts and associated plot information.',
        'Developed APIs with input validation and exception handling to ensure reliable application processing.',
        'Integrated Google Maps API for map and location-based functionality.',
        'Used Git and GitHub for version control and source code management.',
        'Tested and documented REST APIs using Swagger and collaborated directly with clients to understand requirements, resolve issues, and deliver project milestones.'
      ]
    },
    {
      name: 'Inventory Management System',
      technologies: ['C#','ASP.NET Core','ASP.NET Core Web API','Entity Framework Core','SQL Server','LINQ','JavaScript','jQuery','Bootstrap','Git','GitHub','Swagger'],
      bullets: [
        'Developed and maintained a web-based Inventory Management System using C#, ASP.NET Core, ASP.NET Core Web API, Entity Framework Core, and SQL Server.',
        'Designed and developed RESTful Web APIs for product, category, supplier, stock, and inventory management.',
        'Implemented CRUD operations for products, categories, suppliers, and inventory records using Entity Framework Core.',
        'Designed database entities and relationships and managed data using SQL Server and LINQ.',
        'Implemented stock-in and stock-out functionality to maintain real-time inventory records.',
        'Developed APIs for product search, filtering, stock availability, and inventory tracking.',
        'Implemented input validation and exception handling to ensure reliable API processing.',
        'Integrated frontend components with backend APIs using JavaScript, jQuery, AJAX, and Bootstrap.',
        'Used Swagger for REST API documentation and testing.',
        'Used Git and GitHub for version control and source code management.'
      ]
    }
  ],
  education: [
    { degree: 'B.Sc. (Computer Science)', institution: 'S.P.D.M. ACS College, Shirpur', detail: 'Overall CGPA: 7.94', date: '06/2026', location: 'Shirpur, India' },
    { degree: '12th', institution: 'Smt. Rayabai Bhivsan Chavan ACS College, Arthe', detail: 'Percentage: 73.67%', date: '', location: '' }
  ]
} as const;
