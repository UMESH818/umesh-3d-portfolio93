import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Scene from './components/Scene';
import Reveal from './components/Reveal';
import { resume } from './data/resume';

const nav = ['Home','About','Experience','Projects','Skills','Education','Contact'];
const initials = 'US';

function App() {
  const [menu, setMenu] = useState(false);
  const [openProject, setOpenProject] = useState<number | null>(null);
  const scrollTo = (id: string) => { document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: 'smooth' }); setMenu(false); };

  return <div className="site-shell">
    <header className="nav-wrap">
      <nav className="nav glass" aria-label="Primary navigation">
        <button className="brand" onClick={() => scrollTo('Home')} aria-label="Go to home"><span className="brand-mark">{initials}</span><span>UMESH SUTAR</span></button>
        <div className="nav-links">{nav.map(item => <button key={item} onClick={() => scrollTo(item)}>{item}</button>)}</div>
        <button className="menu-btn" onClick={() => setMenu(v => !v)} aria-label="Toggle navigation menu" aria-expanded={menu}>☰</button>
      </nav>
      <AnimatePresence>{menu && <motion.div className="mobile-menu glass" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>{nav.map(item => <button key={item} onClick={() => scrollTo(item)}>{item}</button>)}</motion.div>}</AnimatePresence>
    </header>

    <main>
      <section id="home" className="hero section">
        <Scene />
        <div className="hero-grid" />
        <div className="hero-copy">
          <Reveal><div className="eyebrow"><span className="pulse" /> AVAILABLE FOR .NET DEVELOPMENT OPPORTUNITIES</div></Reveal>
          <Reveal delay={0.08}><h1>{resume.name.split(' ')[0]} <span>Sutar</span></h1></Reveal>
          <Reveal delay={0.16}><p className="hero-title">{resume.title} <span>•</span> C# <span>•</span> ASP.NET Core <span>•</span> Web API</p></Reveal>
          <Reveal delay={0.24}><p className="hero-summary">{resume.summary}</p></Reveal>
          <Reveal delay={0.32}><div className="cta-row"><button className="btn btn-primary" onClick={() => scrollTo('Projects')}>View My Work <span>↗</span></button><a className="btn btn-ghost" href="/Umesh_Sutar_Dotnet_Resume.pdf" download>Download Resume ↓</a></div></Reveal>
        </div>
        <Reveal delay={0.28} className="hero-photo-wrap"><div className="photo-card"><div className="photo-glow" /><img src="/profile.png" alt="Professional portrait of Umesh Sutar" /><div className="photo-label"><span>01</span><span>.NET DEVELOPER</span></div></div></Reveal>
        <div className="scroll-cue">SCROLL <span>↓</span></div>
      </section>

      <section id="about" className="section content-section">
        <Reveal><div className="section-head"><span>01 / ABOUT</span><h2>Building practical software<br /><em>with a clean backend mindset.</em></h2></div></Reveal>
        <div className="about-grid"><Reveal><div className="about-copy"><p>{resume.summary}</p><div className="fact-row"><div><strong>1.2 yrs</strong><span>Professional experience</span></div><div><strong>6 mos</strong><span>Internship experience</span></div><div><strong>15+</strong><span>RESTful APIs in a project</span></div></div></div></Reveal><Reveal delay={0.1}><div className="about-cards"><article className="glass info-card"><span>FOCUS</span><strong>Web applications & RESTful Web APIs</strong><p>C#, ASP.NET Core, EF Core, LINQ and SQL Server.</p></article><article className="glass info-card"><span>SECURITY</span><strong>JWT + Role-Based Authorization</strong><p>Authentication and access control are part of the project experience.</p></article><article className="glass info-card"><span>WORKFLOW</span><strong>Clean, reusable, maintainable components</strong><p>Experience across development, testing, debugging and maintenance.</p></article></div></Reveal></div>
      </section>

      <section id="experience" className="section content-section dark-band">
        <Reveal><div className="section-head"><span>02 / EXPERIENCE</span><h2>Professional<br /><em>experience.</em></h2></div></Reveal>
        <div className="timeline">{resume.experience.map((job, i) => <Reveal key={job.role} delay={i * 0.08}><article className="timeline-item"><div className="timeline-dot">0{i+1}</div><div className="timeline-main"><div className="job-meta"><span>{job.dates}</span><span>{job.location}</span></div><h3>{job.role}</h3><h4>{job.company}</h4><ul>{job.bullets.map(b => <li key={b}>{b}</li>)}</ul></div></article></Reveal>)}</div>
      </section>

      <section id="projects" className="section content-section">
        <Reveal><div className="section-head"><span>03 / PROJECTS</span><h2>Selected work,<br /><em>built around real workflows.</em></h2></div></Reveal>
        <div className="projects">{resume.projects.map((project, i) => <Reveal key={project.name} delay={i * 0.1}><article className={`project-card ${openProject === i ? 'open' : ''}`}><div className="project-top"><div><span className="project-index">0{i+1}</span><h3>{project.name}</h3></div><button className="expand" onClick={() => setOpenProject(openProject === i ? null : i)} aria-expanded={openProject === i}>{openProject === i ? '×' : '+'}</button></div><div className="project-tech">{project.technologies.map(t => <span key={t}>{t}</span>)}</div><AnimatePresence initial={false}>{openProject === i && <motion.div className="project-details" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}><ul>{project.bullets.map(b => <li key={b}>{b}</li>)}</ul></motion.div>}</AnimatePresence><button className="project-toggle" onClick={() => setOpenProject(openProject === i ? null : i)}>{openProject === i ? 'Close details' : 'Explore project'} <span>↗</span></button></article></Reveal>)}</div>
      </section>

      <section id="skills" className="section content-section dark-band">
        <Reveal><div className="section-head"><span>04 / SKILLS</span><h2>A practical stack<br /><em>for backend-driven products.</em></h2></div></Reveal>
        <div className="skill-grid">{Object.entries(resume.skills).map(([group, items], i) => <Reveal key={group} delay={(i % 3) * 0.05}><article className="skill-card glass"><span className="skill-number">{String(i+1).padStart(2,'0')}</span><h3>{group}</h3><div className="tags">{items.map(skill => <span key={skill}>{skill}</span>)}</div></article></Reveal>)}</div>
      </section>

      <section id="education" className="section content-section">
        <Reveal><div className="section-head"><span>05 / EDUCATION</span><h2>Academic<br /><em>foundation.</em></h2></div></Reveal>
        <div className="education-grid">{resume.education.map((edu, i) => <Reveal key={edu.degree} delay={i * 0.1}><article className="edu-card"><div className="edu-year">{edu.date || '—'}</div><div><h3>{edu.degree}</h3><h4>{edu.institution}</h4><p>{edu.detail}</p>{edu.location && <span>{edu.location}</span>}</div></article></Reveal>)}</div>
      </section>

      <section id="contact" className="section contact-section">
        <Scene />
        <div className="contact-inner"><Reveal><span className="eyebrow">06 / CONTACT</span><h2>Let’s build something<br /><em>meaningful.</em></h2><p>For opportunities, project discussions, or professional conversations, reach out directly.</p><div className="contact-actions"><a className="btn btn-primary" href={`mailto:${resume.email}`}>Email Me ↗</a><a className="btn btn-ghost" href={`tel:${resume.phone}`}>Call {resume.phone}</a></div><div className="contact-details"><a href={`mailto:${resume.email}`}>{resume.email}</a><span>{resume.phone}</span><span>{resume.location}</span></div></Reveal></div>
      </section>
    </main>

    <footer><span>© {new Date().getFullYear()} {resume.name}</span><span>{resume.title}</span></footer>
  </div>;
}
export default App;
